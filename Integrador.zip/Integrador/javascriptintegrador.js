const colaborarLink = document.getElementById("colaborar-link");
const inscripcionesLink = document.getElementById("inscripciones-link");

const formularioContenedor = document.getElementById("formulario-contenedor");
const colaborarFormContenedor = document.getElementById("colaborar-contenedor");

let inscripcionesVisible = false;

let colaborarVisible = false;

function toggleInscripcionesForm() {
    if (inscripcionesVisible) {
        formularioContenedor.style.display = "none"; 
    } else {
        formularioContenedor.style.display = "block"; }
    inscripcionesVisible = !inscripcionesVisible;}
function toggleColaborarForm() {
    if (colaborarVisible) {
        colaborarFormContenedor.style.display = "none"; 
    } else {
        colaborarFormContenedor.style.display = "block"; 
    }
    colaborarVisible = !colaborarVisible; }

inscripcionesLink.addEventListener("click", function (e) {
    e.preventDefault(); 
    toggleInscripcionesForm(); 
    colaborarFormContenedor.style.display = "none"; });

colaborarLink.addEventListener("click", function (e) {
    e.preventDefault(); 
    toggleColaborarForm(); 
    formularioContenedor.style.display = "none";});